//
//  GratitudeView.swift
//  
//
//  Created by Louisa Gareiss on 15/4/23.
//

import SwiftUI

struct GratitudeEntry: Identifiable {
    let id = UUID()
    let date: Date
    let reason1: String
    let reason2: String
    let reason3: String
}

class GratitudeViewModel: ObservableObject {
    @Published var entries: [GratitudeEntry] = []
    
    func addEntry(reason1: String, reason2: String, reason3: String) {
        let entry = GratitudeEntry(date: Date(), reason1: reason1, reason2: reason2, reason3: reason3)
        entries.append(entry)
    }
}

struct GratitudeView: View {
    @State private var reason1 = ""
    @State private var reason2 = ""
    @State private var reason3 = ""
    @State private var showAlert = false
    
    @ObservedObject private var viewModel = GratitudeViewModel()
    
    var body: some View {
        VStack {
            Text("What are three things you are grateful for today?")
                .font(.headline)
                .padding()
            
            TextField("1st thing you're grateful for...", text: $reason1)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
            
            TextField("2nd thing you're grateful for...", text: $reason2)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
            
            TextField("3rd thing you're grateful for...", text: $reason3)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
            
            Button(action: {
                if reason1.isEmpty || reason2.isEmpty {
                    showAlert = true
                } else {
                    viewModel.addEntry(reason1: reason1, reason2: reason2, reason3: reason3)
                    reason1 = ""
                    reason2 = ""
                    reason3 = ""
                }
            }) {
                Text("Save")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }.navigationTitle("Gratitude")
        .padding()
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("You got this!"),
                message: Text("Please enter at least two things you're grateful for."),
                dismissButton: .default(Text("I'm thinking"))
            )
        }
        Spacer()
        
        List(viewModel.entries) { entry in
            VStack(alignment: .leading) {
                Text(entry.date, formatter: dateFormatter)
                    .bold()
                Text(entry.reason1)
                Text(entry.reason2)
                Text(entry.reason3)
            }
        }
    }
    
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter
    }()
}

struct GratitudeView_Previews: PreviewProvider {
    static var previews: some View {
        GratitudeView()
    }
}


