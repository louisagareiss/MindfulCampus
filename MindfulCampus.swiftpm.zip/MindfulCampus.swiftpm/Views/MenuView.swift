//
//  MenuView.swift
//  
//
//  Created by Louisa Gareiss on 12/4/23.
//

import SwiftUI

struct MenuView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink(destination: MoodTrackerView()) {
                    HStack {
                        Image(systemName: "face.smiling.fill")
                            .foregroundColor(.blue)
                            .imageScale(.large)
                        Text("Mood Tracker")
                    }
                }
                NavigationLink(destination: JournalingView()) {
                    HStack {
                        Image(systemName: "book.fill")
                            .foregroundColor(.green)
                            .imageScale(.large)
                        Text("Journaling")
                    }
                }
                NavigationLink(destination: MotivationWallView()) {
                    HStack {
                        Image(systemName: "quote.bubble.fill")
                            .foregroundColor(.orange)
                            .imageScale(.large)
                        Text("Motivation Wall")
                    }
                }
                NavigationLink(destination: GratitudeView()) {
                    HStack {
                        Image(systemName: "heart.fill")
                            .foregroundColor(.red)
                            .imageScale(.large)
                        Text("Gratitude")
                    }
                }
                NavigationLink(destination: HelpfulResourcesView()) {
                    HStack {
                        Image(systemName: "lightbulb.fill")
                            .foregroundColor(.yellow)
                            .imageScale(.large)
                        Text("Helpful Resources")
                    }
                }
            }
            .navigationBarTitle(Text("MindfulCampus"))
        }
    }
}


