//
//  HelpfulResourcesView.swift
//  
//
//  Created by Louisa Gareiss on 14/4/23.
//

import SwiftUI

struct HelpfulResourcesView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Remember, it's important to seek professional help if you are experiencing mental health concerns or issues. These resources can be a great starting point, but they are not a substitute for medical advice or treatment.")
                .bold()
                .padding(.vertical)
            Text("National Alliance on Mental Illness (NAMI)")
                .bold()
            Text("NAMI offers support, education, and advocacy for individuals and families affected by mental illness. They have a helpline, support groups, and online resources.")
                .padding(.bottom)
            
            Text("Substance Abuse and Mental Health Services Administration (SAMHSA)")
                .bold()
            Text("SAMHSA provides national resources and support for mental health and substance abuse treatment. They have a helpline, treatment locator, and educational resources.")
                .padding(.bottom)
            
            Text("Mental Health America (MHA)")
                .bold()
            Text("MHA offers information, resources, and advocacy for mental health and well-being. They have a screening tool for mental health conditions, support groups, and educational resources.")
                .padding(.bottom)
            
            Text("Crisis Text Line")
                .bold()
            Text("Crisis Text Line provides free, 24/7 support for individuals experiencing a mental health crisis. Text HOME to 741741 to connect with a crisis counselor.")
                .padding(.bottom)
            
            Spacer()
        }.navigationTitle("Helpful Resources")
            .padding(.horizontal)
    }
}

struct HelpfulResourcesView_Previews: PreviewProvider {
    static var previews: some View {
        HelpfulResourcesView()
    }
}
