//
//  JournalingView.swift
//  
//
//  Created by Louisa Gareiss on 12/4/23.
//

import SwiftUI

struct Entry: Identifiable {
    let id = UUID()
    let date: Date
    let content: String
}

class JournalViewModel: ObservableObject {
    @Published var entries: [Entry] = []
    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }
    
    func addEntry(content: String) {
        guard content.split(separator: " ").count >= 10 else {
            // Show an alert or perform some error handling for not meeting the word count requirement
            return
        }
        
        let entry = Entry(date: Date(), content: content)
        entries.append(entry)
    }
    
    func deleteEntry(at index: IndexSet) {
        entries.remove(atOffsets: index)
    }
}

struct JournalingView: View {
    @State private var newEntry: String = ""
    @ObservedObject private var viewModel = JournalViewModel()
    @State private var showErrorAlert = false
    
    var body: some View {
        VStack {
            HStack {
                TextField("Write something...", text: $newEntry)
                
                Button(action: addEntry) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 120, height: 40)
                            .foregroundColor(Color(.systemBlue))
                        Text("Add Entry")
                            .foregroundColor(Color("buttontext"))
                            .font(.subheadline)
                            .bold()
                    }
                }
            }
            .padding()
            
            List {
                ForEach(viewModel.entries) { entry in
                    VStack(alignment: .leading) {
                        Text(viewModel.dateFormatter.string(from: entry.date))
                            .font(.headline)
                        Text(entry.content)
                    }
                }
                .onDelete(perform: viewModel.deleteEntry)
            }
        }
        .navigationTitle("Journal")
        .alert(isPresented: $showErrorAlert) {
            Alert(
                title: Text("Write something"),
                message: Text("Please write at least 10 words. Tip: If you don't want to write full sentences you can also write bullet points."),
                dismissButton: .default(Text("I write"))
            )
        }
    }
    
    private func addEntry() {
        if newEntry.split(separator: " ").count >= 10 {
            viewModel.addEntry(content: newEntry)
            newEntry = ""
        } else {
            showErrorAlert = true
        }
    }
}

struct JournalView: View {
    var body: some View {
        JournalingView()
    }
}

