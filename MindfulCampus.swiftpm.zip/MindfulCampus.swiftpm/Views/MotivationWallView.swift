//
//  MotivationWallView.swift
//  
//
//  Created by Louisa Gareiss on 13/4/23.
//

import SwiftUI

struct MotivationWallView: View {
    @State private var posts: [Post] = []
    @State private var newPostText = ""
    @State private var showAlert = false

    var body: some View {
        VStack {
            HStack {
                TextField("Type your Note here...", text: $newPostText)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                
                Button(action: {
                    if newPostText.isEmpty {
                        showAlert = true
                    } else {
                        addPost()
                    }
                }) {
                    Text("Post")
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .padding()
            
            ScrollView {
                ForEach(posts, id: \.id) { post in
                    PostView(post: post, onDelete: deletePost)
                        .onLongPressGesture {
                            deletePost(post)
                        }
                }
            }
        }
        .navigationTitle("Motivation Wall")
        .padding()
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Think Different :)"),
                message: Text("Please write something more."),
                dismissButton: .default(Text("OK"))
            )
        }
    }

    func addPost() {
        let newPost = Post(id: UUID(), text: newPostText, color: getRandomColor())
        posts.append(newPost)
        newPostText = ""
    }
    
    func deletePost(_ post: Post) {
        posts.removeAll(where: { $0.id == post.id })
    }
    
    func getRandomColor() -> Color {
        let colors: [Color] = [.red, .orange, .yellow, .green, .blue, .purple]
        return colors.randomElement() ?? .gray
    }
}

struct Post: Identifiable {
    let id: UUID
    let text: String
    let color: Color
}

struct PostView: View {
    let post: Post
    let onDelete: (Post) -> Void
    
    var body: some View {
        HStack {
            Text(post.text)
                .padding()
                .background(post.color)
                .foregroundColor(.white)
                .cornerRadius(10)
                
            
            Button(action: {
                onDelete(post)
            }) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
            }
        }
        .padding(.vertical, 5)
    }
}

struct MotivationWallView_Previews: PreviewProvider {
    static var previews: some View {
        MotivationWallView()
    }
}




