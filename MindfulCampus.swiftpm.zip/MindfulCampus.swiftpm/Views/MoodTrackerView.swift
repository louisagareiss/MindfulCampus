//
//  MoodTrackerView.swift
//  
//
//  Created by Louisa Gareiss on 15/4/23.
//


import SwiftUI

struct MoodTrackerView: View {
    @State private var mood: Double = 5
    @State private var moodRecords: [(Date, Double)] = []
    
    var body: some View {
        VStack {
            Text("How do you feel today?")
                .font(.headline)
            Slider(value: $mood, in: 1...10, step: 1.0) { _ in }
                .padding(.horizontal)
            
            Text("\(Int(mood))")
                .font(.largeTitle)
            
            Text("\(emojiForMood(mood))")
                .font(.system(size: 72))
                .padding(.top, 20)
            
            Button(action: {
                recordMood()
            }) {
                Text("Save Mood")
                    .font(.headline)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.top, 20)
            
            if !moodRecords.isEmpty {
                List(moodRecords, id: \.0) { record in
                    HStack {
                        Text("\(formattedDateTime(record.0))")
                            .font(.subheadline)
                        
                        Spacer()
                        
                        Text("\(Int(record.1))")
                            .font(.subheadline)
                        
                        Text("\(emojiForMood(record.1))")
                            .font(.system(size: 24))
                    }
                }
                .padding(.top, 20)
            }
        }.navigationTitle("Mood Tracker")
        
        Spacer()
    }
    
    private func recordMood() {
        let currentDate = Date()
        moodRecords.append((currentDate, mood))
    }
    
    private func emojiForMood(_ mood: Double) -> String {
        switch mood {
        case 1...4:
            return "😔"
        case 5:
            return "😐"
        case 6...10:
            return "😊"
        default:
            return ""
        }
    }
    
    private func formattedDateTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

struct MoodTrackerView_Previews: PreviewProvider {
    static var previews: some View {
        MoodTrackerView()
    }
}


